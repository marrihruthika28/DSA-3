/**
 * MINI SEARCH ENGINE - MINIMAL FRONTEND CONTROLLER (app.js)
 * Final DSA Project
 */

document.addEventListener('DOMContentLoaded', () => {
    // Initialize Core DSA Engine
    const invertedIndex = new InvertedIndex();
    const searchHistory = new SearchHistoryQueue(5);

    // Navigation & View Elements
    const navSearchBtn = document.getElementById('navSearchBtn');
    const navManageBtn = document.getElementById('navManageBtn');
    const navIndexBtn = document.getElementById('navIndexBtn');

    const viewSearch = document.getElementById('viewSearch');
    const viewManage = document.getElementById('viewManage');
    const viewIndex = document.getElementById('viewIndex');

    // Search Controls
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.getElementById('searchBtn');
    const clearQueryBtn = document.getElementById('clearQueryBtn');
    const autocompleteDropdown = document.getElementById('autocompleteDropdown');
    const recentSearchesList = document.getElementById('recentSearchesList');
    const clearHistoryBtn = document.getElementById('clearHistoryBtn');
    const resultsContainer = document.getElementById('resultsContainer');
    const resultsStats = document.getElementById('resultsStats');

    // Document Management Controls
    const dropzone = document.getElementById('dropzone');
    const fileInput = document.getElementById('fileInput');
    const formAddWebpage = document.getElementById('formAddWebpage');
    const docCollectionGrid = document.getElementById('docCollectionGrid');
    const btnResetSampleDocs = document.getElementById('btnResetSampleDocs');

    // Inverted Index View Controls
    const indexTableBody = document.getElementById('indexTableBody');
    const indexSearchInput = document.getElementById('indexSearchInput');

    // View Document Modal
    const modalViewDoc = document.getElementById('modalViewDoc');
    const viewModalTitle = document.getElementById('viewModalTitle');
    const viewModalContent = document.getElementById('viewModalContent');

    // -------------------------------------------------------------------------
    // 1. SECTION NAVIGATION CONTROLLER
    // -------------------------------------------------------------------------
    function showSection(section) {
        [navSearchBtn, navManageBtn, navIndexBtn].forEach(btn => btn.classList.remove('active'));
        [viewSearch, viewManage, viewIndex].forEach(view => view.classList.remove('active'));

        if (section === 'search') {
            navSearchBtn.classList.add('active');
            viewSearch.classList.add('active');
        } else if (section === 'manage') {
            navManageBtn.classList.add('active');
            viewManage.classList.add('active');
        } else if (section === 'index') {
            navIndexBtn.classList.add('active');
            viewIndex.classList.add('active');
        }
    }

    navSearchBtn.addEventListener('click', () => showSection('search'));
    navManageBtn.addEventListener('click', () => showSection('manage'));
    navIndexBtn.addEventListener('click', () => showSection('index'));

    // -------------------------------------------------------------------------
    // 2. DATA INITIALIZATION & SAMPLES
    // -------------------------------------------------------------------------
    function initData() {
        // Load Search History
        const savedHistory = DatabaseManager.loadHistory();
        searchHistory.load(savedHistory);
        renderHistory();

        // Load Documents
        const savedDocs = DatabaseManager.loadDocuments();
        if (savedDocs && Array.isArray(savedDocs) && savedDocs.length > 0) {
            savedDocs.forEach(doc => invertedIndex.addDocument(doc));
            updateViews();
        } else {
            loadDefaultSamples();
        }
    }

    function loadDefaultSamples() {
        const samples = [
            {
                id: "doc_1",
                title: "Introduction to Inverted Index in Search Engines",
                content: "An inverted index is a foundational data structure used extensively in modern search engines and information retrieval systems. Unlike a forward index which maps documents to words, an inverted index maps words or keywords to the documents where they appear. This enables fast O(1) term lookup times using hash maps. During query execution, the search engine retrieves posting lists for each keyword, computes term frequencies (TF) and inverse document frequencies (IDF), and ranks results efficiently using sorting algorithms like QuickSort.",
                url: "https://dsa-course.edu/inverted-index-basics",
                type: "Webpage",
                addedAt: new Date().toISOString()
            },
            {
                id: "doc_2",
                title: "Sorting Algorithms: QuickSort & MergeSort",
                content: "Sorting algorithms are fundamental searching and ordering techniques in computer science. QuickSort is a divide-and-conquer algorithm that selects a pivot element and partitions the array into smaller sub-arrays. It achieves an average time complexity of O(N log N) and space complexity of O(log N). MergeSort guarantees O(N log N) performance in all cases using stable recursion. In search engines, QuickSort is used to rank documents based on relevance score, phrase matching bonuses, and keyword frequency.",
                url: "https://dsa-course.edu/sorting-quicksort-mergesort",
                type: "Article",
                addedAt: new Date().toISOString()
            },
            {
                id: "doc_3",
                title: "Binary Trees and Trie Data Structures",
                content: "Trees are non-linear data structures consisting of nodes connected by edges. A Binary Search Tree (BST) maintains sorted key order allowing log N insertion and lookup. A Trie (also known as a prefix tree) is a specialized tree structure optimized for string lookup and dictionary autocomplete suggestions. Search engine search bars utilize Tries to suggest queries as the user types each character in real time.",
                url: "https://dsa-course.edu/trie-and-binary-trees",
                type: "Document",
                addedAt: new Date().toISOString()
            },
            {
                id: "doc_4",
                title: "Hash Tables and Collision Resolution",
                content: "A Hash Table maps keys to values using a hash function, providing O(1) average time complexity for insert, search, and delete operations. Collisions occur when two different keys map to the same bucket index. Common collision resolution methods include Separate Chaining using linked lists and Open Addressing via Linear Probing or Double Hashing. Hash tables serve as the core dictionary backing inverted indices in mini search engines.",
                url: "https://dsa-course.edu/hash-tables-hashing",
                type: "Webpage",
                addedAt: new Date().toISOString()
            }
        ];

        invertedIndex.clearAll();
        samples.forEach(doc => invertedIndex.addDocument(doc));
        DatabaseManager.saveDocuments(samples);
        updateViews();
    }

    function saveDocuments() {
        DatabaseManager.saveDocuments(invertedIndex.getAllDocuments());
    }

    // -------------------------------------------------------------------------
    // 3. SEARCH ENGINE LOGIC & RELEVANCE RANKING
    // -------------------------------------------------------------------------
    function performSearch(query) {
        if (!query || !query.trim()) return;

        const cleanQuery = query.trim();
        searchInput.value = cleanQuery;
        clearQueryBtn.style.display = 'block';
        hideAutocomplete();

        searchHistory.enqueue(cleanQuery);
        DatabaseManager.saveHistory(searchHistory.getHistory());
        renderHistory();

        showSection('search');

        const results = RelevanceRanker.search(invertedIndex, cleanQuery);
        renderResults(results, cleanQuery);
    }

    function renderResults(results, query) {
        if (results.length === 0) {
            resultsStats.innerHTML = `No results found for "<strong>${escapeHtml(query)}</strong>"`;
            resultsContainer.innerHTML = `
                <div style="background:white;border:1px solid var(--border);border-radius:var(--radius-md);padding:32px;text-align:center;color:var(--text-muted);">
                    No matching documents found. Try searching for keywords like "quicksort", "inverted index", or "trie".
                </div>
            `;
            return;
        }

        resultsStats.innerHTML = `Showing <strong>${results.length}</strong> result${results.length === 1 ? '' : 's'} for "<strong>${escapeHtml(query)}</strong>"`;

        let html = '';
        results.forEach(res => {
            const doc = res.document;
            const highlightedSnippet = highlightText(res.snippet, res.matchedWords);

            html += `
                <div class="result-item-card">
                    <div class="result-item-header">
                        <a href="#" class="result-item-title btn-view-doc" data-doc-id="${doc.id}">${escapeHtml(doc.title)}</a>
                        <span class="score-badge">Relevance ${res.score}%</span>
                    </div>
                    <div class="result-snippet-text">${highlightedSnippet}</div>
                    <div class="result-item-footer">
                        <div class="matched-terms-row">
                            <span>Matched:</span>
                            ${res.matchedWords.map(w => `<span class="term-tag">${escapeHtml(w)}</span>`).join('')}
                        </div>
                        <button class="btn-card-action view btn-view-doc" data-doc-id="${doc.id}">Read full</button>
                    </div>
                </div>
            `;
        });

        resultsContainer.innerHTML = html;

        document.querySelectorAll('.btn-view-doc').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                openViewDocModal(btn.getAttribute('data-doc-id'));
            });
        });
    }

    // -------------------------------------------------------------------------
    // 4. TRIE AUTOCOMPLETE
    // -------------------------------------------------------------------------
    searchInput.addEventListener('input', () => {
        const query = searchInput.value;
        if (query.trim().length > 0) {
            clearQueryBtn.style.display = 'block';
            const words = query.trim().split(/\s+/);
            const lastWord = words[words.length - 1];

            const suggestions = invertedIndex.trie.getSuggestions(lastWord, 5);
            renderAutocomplete(suggestions, query, lastWord);
        } else {
            clearQueryBtn.style.display = 'none';
            hideAutocomplete();
        }
    });

    function renderAutocomplete(suggestions, fullQuery, lastWord) {
        if (!suggestions || suggestions.length === 0) {
            hideAutocomplete();
            return;
        }

        const prefixWords = fullQuery.trim().split(/\s+/).slice(0, -1).join(' ');
        const prefixStr = prefixWords ? prefixWords + ' ' : '';

        let html = '';
        suggestions.forEach(sugg => {
            const fullSuggestion = prefixStr + sugg;
            html += `
                <div class="autocomplete-item" data-suggestion="${escapeHtml(fullSuggestion)}">
                    <i class="fas fa-search" style="font-size:0.8rem;color:var(--text-light);"></i>
                    <span>${prefixStr}<strong>${escapeHtml(sugg)}</strong></span>
                </div>
            `;
        });

        autocompleteDropdown.innerHTML = html;
        autocompleteDropdown.classList.add('show');

        document.querySelectorAll('.autocomplete-item').forEach(item => {
            item.addEventListener('click', () => {
                performSearch(item.getAttribute('data-suggestion'));
            });
        });
    }

    function hideAutocomplete() {
        autocompleteDropdown.classList.remove('show');
    }

    document.addEventListener('click', (e) => {
        if (!searchInput.contains(e.target) && !autocompleteDropdown.contains(e.target)) {
            hideAutocomplete();
        }
    });

    // -------------------------------------------------------------------------
    // 5. SEARCH HISTORY QUEUE
    // -------------------------------------------------------------------------
    function renderHistory() {
        const history = searchHistory.getHistory();
        if (history.length === 0) {
            recentSearchesList.innerHTML = `<span style="color:var(--text-light);">No recent searches</span>`;
            return;
        }

        let html = '';
        history.forEach(item => {
            html += `<span class="history-chip" data-query="${escapeHtml(item)}">${escapeHtml(item)}</span>`;
        });
        recentSearchesList.innerHTML = html;

        document.querySelectorAll('.history-chip').forEach(chip => {
            chip.addEventListener('click', () => {
                performSearch(chip.getAttribute('data-query'));
            });
        });
    }

    clearHistoryBtn.addEventListener('click', () => {
        searchHistory.clear();
        DatabaseManager.saveHistory([]);
        renderHistory();
    });

    // -------------------------------------------------------------------------
    // 6. UPLOAD & DOCUMENT COLLECTION MANAGEMENT
    // -------------------------------------------------------------------------
    function updateViews() {
        const docs = invertedIndex.getAllDocuments();
        renderCollectionGrid(docs);
        renderIndexTable();
    }

    function renderCollectionGrid(docs) {
        if (docs.length === 0) {
            docCollectionGrid.innerHTML = `
                <div style="grid-column: 1/-1; background:white; border:1px solid var(--border); border-radius:var(--radius-md); padding:32px; text-align:center; color:var(--text-muted);">
                    No documents added yet. Upload a text file or add a webpage above.
                </div>
            `;
            return;
        }

        let html = '';
        docs.forEach(doc => {
            const excerpt = doc.content.length > 120 ? doc.content.substring(0, 120) + '...' : doc.content;
            html += `
                <div class="doc-card-item">
                    <div class="doc-card-header">
                        <h4 class="doc-card-name">${escapeHtml(doc.title)}</h4>
                        <p class="doc-card-text">${escapeHtml(excerpt)}</p>
                    </div>
                    <div class="doc-card-footer">
                        <button class="btn-card-action view btn-view-doc" data-doc-id="${doc.id}">View</button>
                        <button class="btn-card-action delete btn-delete-doc" data-doc-id="${doc.id}">Delete</button>
                    </div>
                </div>
            `;
        });

        docCollectionGrid.innerHTML = html;

        document.querySelectorAll('.btn-view-doc').forEach(btn => {
            btn.addEventListener('click', () => openViewDocModal(btn.getAttribute('data-doc-id')));
        });

        document.querySelectorAll('.btn-delete-doc').forEach(btn => {
            btn.addEventListener('click', () => {
                const docId = btn.getAttribute('data-doc-id');
                if (confirm('Delete this document?')) {
                    invertedIndex.removeDocument(docId);
                    saveDocuments();
                    updateViews();
                    if (searchInput.value.trim()) {
                        performSearch(searchInput.value.trim());
                    }
                }
            });
        });
    }

    // Dropzone & File Upload
    dropzone.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', () => {
        if (fileInput.files.length > 0) {
            const file = fileInput.files[0];
            const reader = new FileReader();
            reader.onload = (e) => {
                const newDoc = {
                    id: 'doc_' + Date.now(),
                    title: file.name.replace(/\.[^/.]+$/, ""),
                    content: e.target.result,
                    type: 'Text File',
                    addedAt: new Date().toISOString()
                };
                invertedIndex.addDocument(newDoc);
                saveDocuments();
                updateViews();
                alert(`Uploaded and indexed "${file.name}"!`);
            };
            reader.readAsText(file);
        }
    });

    // Add Webpage Form
    formAddWebpage.addEventListener('submit', (e) => {
        e.preventDefault();
        const title = document.getElementById('webTitle').value.trim();
        const url = document.getElementById('webUrl').value.trim();
        const content = document.getElementById('webContent').value.trim();

        if (!title || !content) return;

        const newDoc = {
            id: 'doc_' + Date.now(),
            title: title,
            content: content,
            url: url || '',
            type: 'Webpage',
            addedAt: new Date().toISOString()
        };

        invertedIndex.addDocument(newDoc);
        saveDocuments();
        updateViews();
        formAddWebpage.reset();
        alert(`Webpage "${title}" added to index!`);
    });

    btnResetSampleDocs.addEventListener('click', () => {
        if (confirm('Reset document collection back to default sample documents?')) {
            loadDefaultSamples();
        }
    });

    // -------------------------------------------------------------------------
    // 7. INVERTED INDEX INSPECTOR
    // -------------------------------------------------------------------------
    function renderIndexTable(filterTerm = '') {
        const indexMap = invertedIndex.index;
        const sortedTerms = Array.from(indexMap.keys()).sort();
        const filter = filterTerm.toLowerCase().trim();

        if (sortedTerms.length === 0) {
            indexTableBody.innerHTML = `<tr><td colspan="3" style="text-align:center;padding:20px;color:var(--text-muted);">Inverted index is empty.</td></tr>`;
            return;
        }

        let html = '';
        sortedTerms.forEach(term => {
            if (filter && !term.includes(filter)) return;

            const postings = indexMap.get(term);
            const postingsHtml = postings.map(p => `Doc: <strong>${p.docId}</strong> (TF: ${p.tf})`).join(', ');

            html += `
                <tr>
                    <td><span class="code-term">${escapeHtml(term)}</span></td>
                    <td>${postings.length}</td>
                    <td style="color:var(--text-muted);">${postingsHtml}</td>
                </tr>
            `;
        });

        indexTableBody.innerHTML = html || `<tr><td colspan="3" style="text-align:center;padding:20px;color:var(--text-muted);">No terms matching "${escapeHtml(filterTerm)}".</td></tr>`;
    }

    indexSearchInput.addEventListener('input', () => {
        renderIndexTable(indexSearchInput.value);
    });

    // -------------------------------------------------------------------------
    // 8. MODAL & UTILITIES
    // -------------------------------------------------------------------------
    function openViewDocModal(docId) {
        const doc = invertedIndex.getDocument(docId);
        if (!doc) return;

        viewModalTitle.textContent = doc.title;
        viewModalContent.textContent = doc.content;
        modalViewDoc.classList.add('active');
    }

    document.querySelectorAll('.btn-close-modal').forEach(btn => {
        btn.addEventListener('click', () => {
            modalViewDoc.classList.remove('active');
        });
    });

    searchBtn.addEventListener('click', () => performSearch(searchInput.value));
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') performSearch(searchInput.value);
    });

    clearQueryBtn.addEventListener('click', () => {
        searchInput.value = '';
        clearQueryBtn.style.display = 'none';
        hideAutocomplete();
        searchInput.focus();
    });

    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }

    function highlightText(text, words) {
        if (!text || !words || words.length === 0) return escapeHtml(text);
        let escaped = escapeHtml(text);
        words.forEach(word => {
            if (!word) return;
            const regex = new RegExp(`(${word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
            escaped = escaped.replace(regex, `<mark class="snippet-highlight">$1</mark>`);
        });
        return escaped;
    }

    // Startup
    initData();
});
