/**
 * MINI SEARCH ENGINE - CORE DATA STRUCTURES & ALGORITHMS
 */

// -------------------------------------------------------------------------
// 1. QUEUE DATA STRUCTURE FOR SEARCH HISTORY
// -------------------------------------------------------------------------
class SearchHistoryQueue {
    constructor(capacity = 5) {
        this.items = [];
        this.capacity = capacity;
    }

    enqueue(query) {
        if (!query || typeof query !== 'string') return;
        const trimmed = query.trim();
        if (!trimmed) return;

        const existingIndex = this.items.indexOf(trimmed);
        if (existingIndex !== -1) {
            this.items.splice(existingIndex, 1);
        }

        this.items.unshift(trimmed);

        while (this.items.length > this.capacity) {
            this.items.pop();
        }
    }

    getHistory() {
        return [...this.items];
    }

    clear() {
        this.items = [];
    }

    load(savedArray) {
        if (Array.isArray(savedArray)) {
            this.items = savedArray.slice(0, this.capacity);
        }
    }
}

// -------------------------------------------------------------------------
// 2. TRIE DATA STRUCTURE FOR AUTOCOMPLETE
// -------------------------------------------------------------------------
class TrieNode {
    constructor() {
        this.children = new Map();
        this.isEndOfWord = false;
        this.frequency = 0;
    }
}

class AutocompleteTrie {
    constructor() {
        this.root = new TrieNode();
    }

    insert(word) {
        if (!word) return;
        let node = this.root;
        const cleanWord = word.toLowerCase();

        for (let i = 0; i < cleanWord.length; i++) {
            const char = cleanWord[i];
            if (!node.children.has(char)) {
                node.children.set(char, new TrieNode());
            }
            node = node.children.get(char);
        }
        node.isEndOfWord = true;
        node.frequency += 1;
    }

    getSuggestions(prefix, maxResults = 5) {
        if (!prefix) return [];
        const cleanPrefix = prefix.toLowerCase();
        let node = this.root;

        for (let i = 0; i < cleanPrefix.length; i++) {
            const char = cleanPrefix[i];
            if (!node.children.has(char)) {
                return [];
            }
            node = node.children.get(char);
        }

        const suggestions = [];
        this._dfsCollect(node, cleanPrefix, suggestions, maxResults);
        return suggestions;
    }

    _dfsCollect(node, currentPrefix, suggestions, maxResults) {
        if (suggestions.length >= maxResults) return;

        if (node.isEndOfWord) {
            suggestions.push(currentPrefix);
        }

        for (const [char, childNode] of node.children.entries()) {
            if (suggestions.length >= maxResults) break;
            this._dfsCollect(childNode, currentPrefix + char, suggestions, maxResults);
        }
    }

    clear() {
        this.root = new TrieNode();
    }
}

// -------------------------------------------------------------------------
// 3. TEXT PROCESSING, TOKENIZATION & SNIPPET GENERATION
// -------------------------------------------------------------------------
class TextProcessor {
    static STOP_WORDS = new Set([
        'a', 'about', 'above', 'after', 'again', 'against', 'all', 'am', 'an', 'and', 'any', 'are', 'aren\'t', 
        'as', 'at', 'be', 'because', 'been', 'before', 'being', 'below', 'between', 'both', 'but', 'by', 
        'can', 'cannot', 'could', 'did', 'do', 'does', 'doing', 'down', 'during', 'each', 'few', 'for', 
        'from', 'further', 'had', 'has', 'have', 'having', 'he', 'her', 'here', 'hers', 'herself', 'him', 
        'himself', 'his', 'how', 'i', 'if', 'in', 'into', 'is', 'it', 'its', 'itself', 'just', 'me', 
        'more', 'most', 'my', 'myself', 'no', 'nor', 'not', 'of', 'off', 'on', 'once', 'only', 'or', 
        'other', 'our', 'ours', 'ourselves', 'out', 'over', 'own', 'same', 'she', 'should', 'so', 'some', 
        'such', 'than', 'that', 'the', 'their', 'theirs', 'them', 'themselves', 'then', 'there', 'these', 
        'they', 'this', 'those', 'through', 'to', 'too', 'under', 'until', 'up', 'very', 'was', 'we', 
        'were', 'what', 'when', 'where', 'which', 'while', 'who', 'whom', 'why', 'with', 'would', 'you', 
        'your', 'yours', 'yourself', 'yourselves'
    ]);

    static tokenizeWithPositions(text) {
        if (!text) return [];
        const cleanText = text.replace(/<[^>]*>/g, ' ');
        const regex = /[a-zA-Z0-9]+/g;
        const tokens = [];
        let match;
        let position = 0;

        while ((match = regex.exec(cleanText)) !== null) {
            const rawWord = match[0];
            const normalized = rawWord.toLowerCase();
            tokens.push({
                word: normalized,
                position: position++,
                rawWord: rawWord
            });
        }

        return tokens;
    }

    static extractTerms(text) {
        const tokens = this.tokenizeWithPositions(text);
        return tokens
            .filter(t => t.word.length > 1 && !this.STOP_WORDS.has(t.word))
            .map(t => t.word);
    }

    static generateSnippet(content, queryKeywords, maxLength = 160) {
        if (!content) return '';
        if (!queryKeywords || queryKeywords.length === 0) {
            return content.length > maxLength ? content.substring(0, maxLength) + '...' : content;
        }

        const lowerContent = content.toLowerCase();
        let bestIndex = -1;

        for (const keyword of queryKeywords) {
            const idx = lowerContent.indexOf(keyword.toLowerCase());
            if (idx !== -1 && (bestIndex === -1 || idx < bestIndex)) {
                bestIndex = idx;
            }
        }

        if (bestIndex === -1) {
            return content.length > maxLength ? content.substring(0, maxLength) + '...' : content;
        }

        const start = Math.max(0, bestIndex - 40);
        const end = Math.min(content.length, start + maxLength);
        
        let snippet = content.substring(start, end);
        if (start > 0) snippet = '...' + snippet;
        if (end < content.length) snippet = snippet + '...';

        return snippet;
    }
}

// -------------------------------------------------------------------------
// 4. INVERTED INDEX DATA STRUCTURE
// -------------------------------------------------------------------------
class InvertedIndex {
    constructor() {
        this.index = new Map();
        this.totalDocuments = 0;
        this.documents = new Map();
        this.trie = new AutocompleteTrie();
    }

    addDocument(doc) {
        if (!doc || !doc.id || !doc.content) return;

        this.documents.set(doc.id, doc);
        this.totalDocuments = this.documents.size;

        const titleTokens = TextProcessor.tokenizeWithPositions(doc.title || '');
        const contentTokens = TextProcessor.tokenizeWithPositions(doc.content);
        const docTermMap = new Map();

        titleTokens.forEach(token => {
            if (TextProcessor.STOP_WORDS.has(token.word)) return;
            this.trie.insert(token.word);

            if (!docTermMap.has(token.word)) {
                docTermMap.set(token.word, { tf: 2, positions: [token.position] });
            } else {
                const entry = docTermMap.get(token.word);
                entry.tf += 2;
                entry.positions.push(token.position);
            }
        });

        contentTokens.forEach(token => {
            if (TextProcessor.STOP_WORDS.has(token.word)) return;
            this.trie.insert(token.word);

            if (!docTermMap.has(token.word)) {
                docTermMap.set(token.word, { tf: 1, positions: [token.position] });
            } else {
                const entry = docTermMap.get(token.word);
                entry.tf += 1;
                entry.positions.push(token.position);
            }
        });

        for (const [term, data] of docTermMap.entries()) {
            if (!this.index.has(term)) {
                this.index.set(term, []);
            }
            this.index.get(term).push({
                docId: doc.id,
                tf: data.tf,
                positions: data.positions
            });
        }
    }

    removeDocument(docId) {
        if (!this.documents.has(docId)) return false;

        this.documents.delete(docId);
        this.totalDocuments = this.documents.size;

        for (const [term, postingList] of this.index.entries()) {
            const filteredList = postingList.filter(posting => posting.docId !== docId);
            if (filteredList.length === 0) {
                this.index.delete(term);
            } else {
                this.index.set(term, filteredList);
            }
        }

        this.rebuildTrie();
        return true;
    }

    rebuildTrie() {
        this.trie.clear();
        for (const term of this.index.keys()) {
            this.trie.insert(term);
        }
    }

    getPostings(term) {
        const cleanTerm = term.toLowerCase().trim();
        return this.index.get(cleanTerm) || [];
    }

    getDocument(docId) {
        return this.documents.get(docId);
    }

    getAllDocuments() {
        return Array.from(this.documents.values());
    }

    clearAll() {
        this.index.clear();
        this.documents.clear();
        this.totalDocuments = 0;
        this.trie.clear();
    }
}

// -------------------------------------------------------------------------
// 5. RELEVANCE RANKING & QUICKSORT
// -------------------------------------------------------------------------
class RelevanceRanker {
    static quickSortResults(results) {
        if (results.length <= 1) return results;

        const pivot = results[Math.floor(results.length / 2)];
        const left = [];
        const right = [];
        const equal = [];

        for (const item of results) {
            if (item.score > pivot.score) {
                left.push(item);
            } else if (item.score < pivot.score) {
                right.push(item);
            } else {
                equal.push(item);
            }
        }

        return [
            ...this.quickSortResults(left),
            ...equal,
            ...this.quickSortResults(right)
        ];
    }

    static search(invertedIndex, query) {
        if (!query || typeof query !== 'string' || !query.trim()) {
            return [];
        }

        const rawQuery = query.trim();
        const isPhraseQuery = rawQuery.startsWith('"') && rawQuery.endsWith('"');
        const cleanQueryText = isPhraseQuery ? rawQuery.slice(1, -1) : rawQuery;

        const queryTerms = TextProcessor.extractTerms(cleanQueryText);
        if (queryTerms.length === 0) return [];

        const docScores = new Map();
        const totalDocs = invertedIndex.totalDocuments || 1;

        queryTerms.forEach(term => {
            const postings = invertedIndex.getPostings(term);
            if (postings.length === 0) return;

            const docFrequency = postings.length;
            const idf = Math.log(1 + (totalDocs / (docFrequency || 1)));

            postings.forEach(posting => {
                const docId = posting.docId;
                const tf = posting.tf;
                const termScore = tf * idf;

                if (!docScores.has(docId)) {
                    docScores.set(docId, {
                        docId: docId,
                        score: termScore,
                        matchedTerms: new Set([term]),
                        positionsMap: new Map([[term, posting.positions]])
                    });
                } else {
                    const entry = docScores.get(docId);
                    entry.score += termScore;
                    entry.matchedTerms.add(term);
                    entry.positionsMap.set(term, posting.positions);
                }
            });
        });

        if (queryTerms.length > 1) {
            for (const [docId, entry] of docScores.entries()) {
                if (entry.matchedTerms.size === queryTerms.length) {
                    const firstTermPositions = entry.positionsMap.get(queryTerms[0]) || [];
                    let phraseMatchFound = false;

                    for (const pos of firstTermPositions) {
                        let consecutive = true;
                        for (let i = 1; i < queryTerms.length; i++) {
                            const nextPositions = entry.positionsMap.get(queryTerms[i]) || [];
                            if (!nextPositions.includes(pos + i)) {
                                consecutive = false;
                                break;
                            }
                        }
                        if (consecutive) {
                            phraseMatchFound = true;
                            break;
                        }
                    }

                    if (phraseMatchFound) {
                        entry.score *= 2.5;
                        entry.isPhraseMatch = true;
                    }
                }
            }
        }

        const results = [];
        for (const [docId, data] of docScores.entries()) {
            const document = invertedIndex.getDocument(docId);
            if (!document) continue;

            const matchedWordsArray = Array.from(data.matchedTerms);
            const snippet = TextProcessor.generateSnippet(document.content, matchedWordsArray);
            const normalizedScore = Math.min(100, Math.round(data.score * 15) / 10 + 5);

            results.push({
                document: document,
                score: normalizedScore,
                rawScore: data.score,
                matchedWords: matchedWordsArray,
                isPhraseMatch: !!data.isPhraseMatch,
                snippet: snippet
            });
        }

        return this.quickSortResults(results);
    }
}

// -------------------------------------------------------------------------
// 6. DATABASE MANAGER
// -------------------------------------------------------------------------
class DatabaseManager {
    static STORAGE_KEY_DOCS = 'final_dsa_search_docs_v2';
    static STORAGE_KEY_HISTORY = 'final_dsa_search_history_v2';

    static saveDocuments(docs) {
        try {
            localStorage.setItem(this.STORAGE_KEY_DOCS, JSON.stringify(docs));
        } catch (e) {
            console.error('LocalStorage write error:', e);
        }
    }

    static loadDocuments() {
        try {
            const data = localStorage.getItem(this.STORAGE_KEY_DOCS);
            return data ? JSON.parse(data) : null;
        } catch (e) {
            console.error('LocalStorage read error:', e);
            return null;
        }
    }

    static saveHistory(historyArray) {
        try {
            localStorage.setItem(this.STORAGE_KEY_HISTORY, JSON.stringify(historyArray));
        } catch (e) {
            console.error('LocalStorage write error:', e);
        }
    }

    static loadHistory() {
        try {
            const data = localStorage.getItem(this.STORAGE_KEY_HISTORY);
            return data ? JSON.parse(data) : [];
        } catch (e) {
            console.error('LocalStorage read error:', e);
            return [];
        }
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        SearchHistoryQueue,
        AutocompleteTrie,
        TextProcessor,
        InvertedIndex,
        RelevanceRanker,
        DatabaseManager
    };
}
