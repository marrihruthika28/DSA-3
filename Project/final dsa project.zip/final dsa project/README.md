# Mini Search Engine - Final DSA Project

A clean, minimal, and fully functional **Mini Search Engine** built for a 2nd-year Data Structures and Algorithms (DSA) project.

## 📌 Features & Structure

- **Clean Minimal Design**: Focused, distraction-free search experience with clean slate typography and subtle borders.
- **Search Engine Homepage**: Clean search input, live Trie autocomplete, recent search queue tags, and ranked search results.
- **Dedicated Upload & Management Page**: Separate section for uploading text files (`.txt`, `.md`, `.json`, `.csv`) and adding custom webpage articles.
- **Dedicated Inverted Index Page**: View all indexed terms, document frequency, and posting lists.
- **Core Algorithms**:
  - Inverted Index (Hash Map key-value mapping)
  - Trie Tree (Prefix-based autocomplete)
  - TF-IDF Relevance Scoring
  - QuickSort (Result ranking algorithm)
  - Fixed Queue ADT (Last 5 search history tracking)

---

## 📂 File Locations

Directory: `C:\2nd year\dsa\final dsa project\`

- `index.html`: Main web application.
- `mini_search_engine.html`: All-in-one standalone file (HTML + CSS + JS in a single file).
- `styles.css`: Sleek minimal design system.
- `dsa_engine.js`: Pure DSA search engine algorithms.
- `app.js`: Minimal UI controller & section navigation.
- `sample_docs.json`: Pre-populated default dataset.
- `final_dsa_project.zip`: Project submission archive.

---

## 🚀 How to Run
- Double click `mini_search_engine.html` or `index.html` to open directly in any browser.
